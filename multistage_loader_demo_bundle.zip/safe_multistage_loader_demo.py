# === Safe Malware Simulation Demo ===
# Purpose: Educational walkthrough of multi-stage loader logic
# Author: Red Team Lab
# License: MIT
# SAFETY NOTICE: This script does not execute real payloads or perform harmful actions.
# It is designed for red team training and security education.

import base64
import ctypes
import time
import os
import getpass
import platform
from Crypto.Cipher import AES
from Crypto.Util.Padding import pad, unpad
import shutil
import tempfile

# Safety switch to disable risky or confusing behavior
SAFETY_MODE = True

# Stage 1: Init - Load and decode mock staging module
def stage1_init():
    print("[Stage 1] Initializing and decoding staging module...")
    encoded_module = base64.b64encode(b"print('Staging module loaded')").decode()
    decoded = base64.b64decode(encoded_module)
    if SAFETY_MODE:
        exec(decoded)
    else:
        print("[DEBUG] Would exec(decoded):", decoded)

# Stage 2: Check - Environment checks (mock anti-analysis)
def stage2_check():
    print("[Stage 2] Performing environment checks...")
    suspicious_users = ['sandbox', 'virus', 'test']
    username = getpass.getuser().lower()
    cpu_count = os.cpu_count()
    system = platform.system()

    red_flags = []

    if any(user in username for user in suspicious_users):
        red_flags.append("Suspicious username")

    if cpu_count and cpu_count < 2:
        red_flags.append("Low CPU count (sandbox?)")

    if system != "Windows":
        red_flags.append("Non-Windows system")

    if red_flags:
        print("[Check] Environment flags detected:", red_flags)
        return False
    else:
        print("[Check] Environment appears clean.")
        return True

# Stage 3: Sleep - Simulate delay and user input
def stage3_sleep():
    print("[Stage 3] Sleeping to evade sandbox...")
    time.sleep(5)
    print("[Stage 3] Simulating user input...")
    for i in range(3):
        print(f"[User Activity] Mouse moved to {i*10},{i*10}")
        time.sleep(0.5)

# Stage 4: Decode payload - AES decryption in memory
def stage4_decode():
    print("[Stage 4] Decrypting payload in memory...")
    key = b'secretkey1234567'  # 16-byte key
    iv = b'initialvector123'   # 16-byte IV
    original_payload = b"echo 'Malicious Code Executed'"

    cipher = AES.new(key, AES.MODE_CBC, iv)
    encrypted = cipher.encrypt(pad(original_payload, AES.block_size))

    cipher = AES.new(key, AES.MODE_CBC, iv)
    decrypted = unpad(cipher.decrypt(encrypted), AES.block_size)
    return decrypted

# Stage 5: Execute - Simulate execution
def stage5_execute(payload):
    print("[Stage 5] Simulating execution of decrypted payload:")
    print(payload.decode())

# Stage 6: Cleanup - Memory wipe and self-delete
def stage6_cleanup():
    print("[Stage 6] Cleaning up...")
    temp_path = tempfile.gettempdir()
    dummy_file = os.path.join(temp_path, "dummy_payload.txt")
    with open(dummy_file, 'w') as f:
        f.write("sensitive data")
    with open(dummy_file, 'w') as f:
        f.write('\x00' * 100)
    os.remove(dummy_file)
    print("[Cleanup] Overwritten and deleted dummy file.")

# Entry point
def run_simulation():
    stage1_init()
    if not stage2_check():
        print("[Abort] Sandbox or VM detected. Exiting.")
        return
    stage3_sleep()
    decrypted_payload = stage4_decode()
    stage5_execute(decrypted_payload)
    stage6_cleanup()

if __name__ == "__main__":
    run_simulation()
